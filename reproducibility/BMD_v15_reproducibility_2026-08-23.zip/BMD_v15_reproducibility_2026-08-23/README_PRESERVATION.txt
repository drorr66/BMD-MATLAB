BMD-MATLAB v1.5 reproducibility bundle
======================================

Preservation date: 2026-08-23

This bundle preserves the exact corrected MATLAB source tree and the complete
50-trial result sets used for the v1.5 cross-environment manuscript update.

Contents
--------
code/BMD_MATLAB_v1_5_FIXED/
    Corrected source tree. Every timed BMD multiplication starts from a fresh,
    compact operand-only manager. Checkpoints use an atomic MAT file; optional
    CSV checkpoint failures cannot abort the benchmark.

results/Linux/results_v15/
    MATLAB Online, GLNXA64, MATLAB R2026a Update 5.

results/Windows/results_v15/
    MATLAB Desktop, PCWIN64, MATLAB R2026a Update 4.

Each environment contains 60 validated case summaries, 3,000 raw core rows,
6,000 raw FFT rows, 3,000 BMD-resident trial rows, run metadata, and both MAT
and CSV recovery checkpoints.

SHA256_MANIFEST.txt contains a SHA-256 digest for every preserved file other
than the manifest itself.
