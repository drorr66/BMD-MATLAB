# BMD-MATLAB v1.3 - adversarial FFT baseline

## Purpose

v1.3 is designed to make the numerical baseline deliberately difficult for
`*BMD`, not to preserve a favorable result.

The package reruns the same 60 deterministic workloads and adds an uncapped
FFT comparison in two states:

1. **FFT_COLD** - both forward FFTs are recomputed for every multiplication.
2. **FFT_RESIDENT** - both operand spectra are precomputed outside the timed
   operation and may be reused.  The timed operation is pointwise spectral
   multiplication + inverse FFT + truncation to the coefficient result.

`FFT_RESIDENT` is the primary adversarial operation-level baseline.  It gives
FFT the benefit of reusable transformed operands, analogous to evaluating an
already-resident representation rather than charging conversion on every use.

The product spectrum is **not** precomputed, because that would precompute the
multiplication result rather than just the operands.  The result must be
returned as coefficients; a frequency-domain-only result is not considered
an equivalent output for this experiment.

## What remains fixed

- the 60 deterministic workloads;
- the `*BMD` implementation;
- the two explicit sparse baselines;
- the predictor and validation logic;
- the five-trial core operation protocol;
- the historical 250,000-position cap for the direct `conv` comparison.

FFT is uncapped and is run on all 60 workloads.

## Timing states

The package reports separately:

- sparse-to-dense materialization;
- dense-to-spectrum precomputation for both operands;
- FFT_COLD operation time;
- FFT_RESIDENT operation time;
- `*BMD`, sparse and eligible direct-`conv` times from the full rerun;
- single-shot totals that include the setup costs appropriate to each state.

The v1.3 operation oracle includes `FFT_RESIDENT`, so any surviving `*BMD`
operation win must beat the strongest FFT state measured here.

## Correctness

Both FFT modes must equal the exact sparse product after rounding.  The
maximum pre-rounding fractional residual must not exceed `1e-6`.

## Run

From a clean extracted folder in MATLAB R2026a:

```matlab
run_all_v13
```

Expected outputs:

- `results_v13/publication_validation_results_v13.csv`
- `results_v13/publication_fft_trials_v13.csv`
- `results_v13/run_metadata_v13.txt`

Run the exact same ZIP unchanged in both environments used for the paper.

## Interpretation

If a `*BMD` win disappears under `FFT_RESIDENT`, v1.3 should report that
without qualification.  If it survives, the resulting claim is materially
stronger because the FFT operands were already resident in transformed form.
