BMD-MATLAB v1.2 canonical cross-platform result snapshot

This snapshot preserves the full v1.2 source package supplied for the experiment and the completed FFT-extension results from both environments.

results_v12/linux:
  MATLAB R2026a Update 5, GLNXA64

results_v12/windows:
  MATLAB R2026a Update 4, PCWIN64

The FFT protocol used 5 operation trials, 3 build trials, no transform reuse, and uncapped FFT eligibility across all 60 workloads. Correctness was checked by exact equality after rounding against the exact sparse product, with residual tolerance 1e-6.

SHA256SUMS_v12.txt contains hashes of the six preserved result/metadata files.
