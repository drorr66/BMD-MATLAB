function [results,fftTrials]=run_publication_validation_v12(varargin)
%RUN_PUBLICATION_VALIDATION_V12 Full v1.1.1 rerun plus FFT baseline on all 60 cases.
%
% Scientific design:
% - Re-runs the complete frozen v1.1.1 60-case protocol unchanged.
% - Adds a separately timed FFT-convolution baseline for all 60 cases.
% - Keeps the historical direct conv cap only for direct conv comparability.
% - FFT is uncapped and uses full dense materialization of the operands.
% - FFT correctness is checked against the exact sparse product after rounding.
% - No precomputed-transform reuse is allowed: every FFT operation trial performs
%   both forward FFTs, pointwise multiplication, and inverse FFT from scratch.
%
p=inputParser;
addParameter(p,'Trials',5,@(x)isnumeric(x)&&isscalar(x)&&x>=3);
addParameter(p,'BuildTrials',3,@(x)isnumeric(x)&&isscalar(x)&&x>=1);
addParameter(p,'PredictTrials',5,@(x)isnumeric(x)&&isscalar(x)&&x>=1);
addParameter(p,'DenseMaxCoefficients',250000,@(x)isnumeric(x)&&isscalar(x)&&x>=1000);
addParameter(p,'FFTTrials',5,@(x)isnumeric(x)&&isscalar(x)&&x>=3);
addParameter(p,'FFTBuildTrials',3,@(x)isnumeric(x)&&isscalar(x)&&x>=1);
addParameter(p,'SaveResults',true,@(x)islogical(x)||ismember(x,[0 1]));
parse(p,varargin{:});

nFFT=round(p.Results.FFTTrials);
nFFTBuild=round(p.Results.FFTBuildTrials);
root=fileparts(mfilename('fullpath'));

% First: full historical rerun, unchanged.
[results,~]=run_publication_validation_v111( ...
    'Trials',round(p.Results.Trials), ...
    'BuildTrials',round(p.Results.BuildTrials), ...
    'PredictTrials',round(p.Results.PredictTrials), ...
    'DenseMaxCoefficients',round(p.Results.DenseMaxCoefficients), ...
    'SaveResults',p.Results.SaveResults);

nCases=height(results);
if nCases~=60
    error('BMD:V12CaseCount','Expected 60 v1.1.1 cases, got %d.',nCases);
end

% Add v1.2 FFT columns.
results.fft_build_median_s=NaN(nCases,1);
results.fft_median_s=NaN(nCases,1);
results.fft_q25_s=NaN(nCases,1);
results.fft_q75_s=NaN(nCases,1);
results.fft_length=NaN(nCases,1);
results.fft_operand_bytes=NaN(nCases,1);
results.fft_result_bytes=NaN(nCases,1);
results.fft_max_fractional_error=NaN(nCases,1);
results.fft_exact_after_rounding=zeros(nCases,1);
results.fft_single_shot_from_sparse_s=NaN(nCases,1);
results.fft_single_shot_speedup_vs_sparse_best=NaN(nCases,1);
results.operation_oracle_winner_v12=strings(nCases,1);
results.operation_oracle_s_v12=NaN(nCases,1);
results.single_shot_oracle_winner_v12=strings(nCases,1);
results.single_shot_oracle_s_v12=NaN(nCases,1);

fftRows=repmat(struct('case_name','','trial',NaN,'fft_s',NaN),nCases*nFFT,1);
pos=0;

fprintf('\nBMD-MATLAB v1.2 FFT extension\n');
fprintf('==============================\n');
fprintf('FFT measured on all %d frozen workloads.\n\n',nCases);

for i=1:nCases
    c=build_publication_case_v11(i);
    if ~strcmp(c.name,results.case_name{i})
        error('BMD:V12CaseOrder','Case mismatch at row %d.',i);
    end

    fprintf('  %02d/%02d %-29s ... ',i,nCases,c.name);

    % Dense materialization from sparse, timed separately and uncapped.
    buildT=zeros(1,nFFTBuild);
    pDense=[]; qDense=[];
    for k=1:nFFTBuild
        tic;
        a=denseFromSparse(c.p_sparse,c.p_degree);
        b=denseFromSparse(c.q_sparse,c.q_degree);
        buildT(k)=toc;
        if k==1
            pDense=a; qDense=b;
        end
    end

    resultLen=c.result_degree_bound+1;
    nfft=2^nextpow2(resultLen);

    % Warm-up outside timing.
    fftConvolve(pDense,qDense,nfft,resultLen);

    % Timed FFT operation trials.
    ft=zeros(1,nFFT);
    firstFFT=[];
    for k=1:nFFT
        tic;
        z=fftConvolve(pDense,qDense,nfft,resultLen);
        ft(k)=toc;
        if k==1, firstFFT=z; end
        pos=pos+1;
        fftRows(pos).case_name=c.name;
        fftRows(pos).trial=k;
        fftRows(pos).fft_s=ft(k);
    end

    % Untimed exact sparse reference and strict FFT correctness gate.
    exactSparse=sparse_terms_multiply(c.p_sparse,c.q_sparse);
    exactDense=denseFromSparse(exactSparse,c.result_degree_bound);
    rounded=round(firstFFT);
    fracErr=max(abs(firstFFT-rounded));
    exactOK=isequal(rounded,exactDense);

    if ~exactOK
        error('BMD:V12FFTValidation','FFT exact-after-rounding failed for %s.',c.name);
    end
    if fracErr>1e-6
        error('BMD:V12FFTResidual','FFT residual %.3g exceeds 1e-6 for %s.',fracErr,c.name);
    end

    results.fft_build_median_s(i)=median(buildT);
    results.fft_median_s(i)=median(ft);
    results.fft_q25_s(i)=pct(ft,.25);
    results.fft_q75_s(i)=pct(ft,.75);
    results.fft_length(i)=nfft;
    results.fft_operand_bytes(i)=workspace_bytes_v11(pDense)+workspace_bytes_v11(qDense);
    results.fft_result_bytes(i)=workspace_bytes_v11(firstFFT);
    results.fft_max_fractional_error(i)=fracErr;
    results.fft_exact_after_rounding(i)=double(exactOK);
    results.fft_single_shot_from_sparse_s(i)=results.fft_build_median_s(i)+results.fft_median_s(i);
    results.fft_single_shot_speedup_vs_sparse_best(i)=results.sparse_best_median_s(i)/max(realmin,results.fft_single_shot_from_sparse_s(i));

    [nm,t]=winnerV12(results.bmd_median_s(i),results.sparse_best_median_s(i), ...
        results.dense_median_s(i),logical(results.dense_eligible(i)),results.fft_median_s(i));
    results.operation_oracle_winner_v12(i)=nm;
    results.operation_oracle_s_v12(i)=t;

    [nm,t]=winnerV12(results.bmd_single_shot_from_sparse_s(i),results.sparse_best_median_s(i), ...
        results.dense_single_shot_from_sparse_s(i),logical(results.dense_eligible(i)),results.fft_single_shot_from_sparse_s(i));
    results.single_shot_oracle_winner_v12(i)=nm;
    results.single_shot_oracle_s_v12(i)=t;

    fprintf('FFT=%.3fms, BMD=%.3fms, sparse*=%.3fms, winner=%s\n', ...
        1000*results.fft_median_s(i),1000*results.bmd_median_s(i), ...
        1000*results.sparse_best_median_s(i),char(results.operation_oracle_winner_v12(i)));
end

fftTrials=struct2table(fftRows(1:pos));

if p.Results.SaveResults
    outDir=fullfile(root,'results');
    if ~exist(outDir,'dir'), mkdir(outDir); end
    writetable(results,fullfile(outDir,'publication_validation_results_v12.csv'));
    writetable(fftTrials,fullfile(outDir,'publication_fft_trials_v12.csv'));
    writeMetadata(outDir,nFFT,nFFTBuild,round(p.Results.DenseMaxCoefficients));
end
end

function out=fftConvolve(a,b,nfft,nout)
fa=fft(a,nfft);
fb=fft(b,nfft);
out=ifft(fa.*fb,'symmetric');
out=out(1:nout);
end

function d=denseFromSparse(s,degreeBound)
d=zeros(1,degreeBound+1);
if isempty(s.exponents), return; end
idx=double(s.exponents)+1;
d(idx)=s.coefficients;
end

function q=pct(x,p)
x=sort(x(:));
pos=1+(numel(x)-1)*p;
lo=floor(pos); hi=ceil(pos);
if lo==hi
    q=x(lo);
else
    q=x(lo)+(pos-lo)*(x(hi)-x(lo));
end
end

function [name,t]=winnerV12(b,s,d,denseEligible,f)
vals=[b s f];
names={'BMD','SPARSE','FFT'};
if denseEligible && isfinite(d)
    vals(end+1)=d;
    names{end+1}='DENSE';
end
[t,idx]=min(vals);
name=string(names{idx});
end

function writeMetadata(outDir,nFFT,nFFTBuild,denseMax)
fid=fopen(fullfile(outDir,'run_metadata_v12.txt'),'w');
if fid<0, return; end
c=onCleanup(@()fclose(fid)); %#ok<NASGU>
fprintf(fid,'BMD-MATLAB v1.2 full rerun + FFT extension\n');
fprintf(fid,'Timestamp: %s\n',datestr(now,31));
fprintf(fid,'MATLAB: %s\n',version);
fprintf(fid,'Computer: %s\n',computer);
fprintf(fid,'FFT trials: %d\n',nFFT);
fprintf(fid,'FFT build trials: %d\n',nFFTBuild);
fprintf(fid,'Historical direct conv cap: %d coefficients\n',denseMax);
fprintf(fid,'FFT eligibility: all 60 cases, uncapped\n');
fprintf(fid,'FFT length: next power of two >= result coefficient count\n');
fprintf(fid,'FFT transform reuse: none\n');
fprintf(fid,'FFT correctness: exact equality after rounding vs exact sparse product\n');
fprintf(fid,'FFT residual tolerance: 1e-6\n');
end
