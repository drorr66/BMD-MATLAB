function [results,fftTrials,coreTrials]=run_publication_validation_v13(varargin)
%RUN_PUBLICATION_VALIDATION_V13 Adversarial numerical-baseline extension.
%
% Goal: make the numerical comparison deliberately difficult for *BMD.
%
% The 60 deterministic workloads, *BMD implementation, sparse baselines,
% predictor, correctness checks, direct-conv cap, and core timing protocol
% are inherited from v1.1.1.  v1.3 adds TWO uncapped FFT baselines on all
% 60 workloads:
%
%   FFT_COLD
%     Dense operands are resident, but both forward FFTs are recomputed on
%     every measured multiplication.  Timing includes forward FFTs,
%     pointwise spectral multiplication, inverse FFT, and truncation.
%
%   FFT_RESIDENT
%     Dense operands AND both operand spectra are resident before the timed
%     multiplication.  The forward FFTs are excluded from the operation
%     timing and may be reused.  Timing includes only pointwise spectral
%     multiplication, inverse FFT, and truncation.  This is intentionally the
%     strongest same-output FFT comparison in this package.  Precomputing the
%     product spectrum itself is NOT allowed because that would precompute
%     the multiplication result rather than merely the operand representation.
%
% For both FFT modes, the returned result is a coefficient vector, matching
% the polynomial output required of the other representations.  Leaving the
% result in the frequency domain is therefore not treated as an equivalent
% multiplication result.
%
% Separate setup measurements are retained for single-shot accounting:
%   sparse -> dense materialization
%   dense -> precomputed operand spectra
%
% No workload-specific tuning, transform-length search, or result caching is
% performed.  nfft is deterministically set to the next power of two at or
% above the required result length.  This keeps the v1.3 challenge strong but
% reproducible and avoids per-case empirical tuning on the measured set.
%
p=inputParser;
addParameter(p,'Trials',5,@(x)isnumeric(x)&&isscalar(x)&&x>=3);
addParameter(p,'BuildTrials',3,@(x)isnumeric(x)&&isscalar(x)&&x>=1);
addParameter(p,'PredictTrials',5,@(x)isnumeric(x)&&isscalar(x)&&x>=1);
addParameter(p,'DenseMaxCoefficients',250000,@(x)isnumeric(x)&&isscalar(x)&&x>=1000);
addParameter(p,'FFTColdTrials',5,@(x)isnumeric(x)&&isscalar(x)&&x>=3);
addParameter(p,'FFTBuildTrials',3,@(x)isnumeric(x)&&isscalar(x)&&x>=1);
addParameter(p,'FFTPrecomputeTrials',3,@(x)isnumeric(x)&&isscalar(x)&&x>=1);
addParameter(p,'FFTResidentTrials',5,@(x)isnumeric(x)&&isscalar(x)&&x>=3);
addParameter(p,'SaveResults',true,@(x)islogical(x)||ismember(x,[0 1]));
addParameter(p,'CheckpointDir','',@(x)ischar(x)||isstring(x));
addParameter(p,'ProgressEvery',10,@(x)isnumeric(x)&&isscalar(x)&&x>=1);
parse(p,varargin{:});

nCold=round(p.Results.FFTColdTrials);
nBuild=round(p.Results.FFTBuildTrials);
nPre=round(p.Results.FFTPrecomputeTrials);
nResident=round(p.Results.FFTResidentTrials);
checkpointDir=char(p.Results.CheckpointDir);
progressEvery=round(p.Results.ProgressEvery);
root=fileparts(mfilename('fullpath'));

% Full core rerun first.  This regenerates *BMD, sparse, and capped direct-conv
% measurements in the same package rather than importing earlier timings.
[results,coreTrials]=run_publication_validation_v111( ...
    'Trials',round(p.Results.Trials), ...
    'BuildTrials',round(p.Results.BuildTrials), ...
    'PredictTrials',round(p.Results.PredictTrials), ...
    'DenseMaxCoefficients',round(p.Results.DenseMaxCoefficients), ...
    'SaveResults',p.Results.SaveResults, ...
    'CheckpointDir',checkpointDir, ...
    'ProgressEvery',progressEvery);

nCases=height(results);
if nCases~=60
    error('BMD:V13CaseCount','Expected 60 cases, got %d.',nCases);
end

% v1.3 FFT columns.
results.fft_build_median_s=NaN(nCases,1);
results.fft_length=NaN(nCases,1);
results.fft_operand_bytes=NaN(nCases,1);
results.fft_precompute_median_s=NaN(nCases,1);
results.fft_spectra_bytes=NaN(nCases,1);

results.fft_cold_median_s=NaN(nCases,1);
results.fft_cold_q25_s=NaN(nCases,1);
results.fft_cold_q75_s=NaN(nCases,1);
results.fft_cold_result_bytes=NaN(nCases,1);
results.fft_cold_max_fractional_error=NaN(nCases,1);
results.fft_cold_exact_after_rounding=zeros(nCases,1);
results.fft_cold_single_shot_from_sparse_s=NaN(nCases,1);

results.fft_resident_median_s=NaN(nCases,1);
results.fft_resident_q25_s=NaN(nCases,1);
results.fft_resident_q75_s=NaN(nCases,1);
results.fft_resident_result_bytes=NaN(nCases,1);
results.fft_resident_max_fractional_error=NaN(nCases,1);
results.fft_resident_exact_after_rounding=zeros(nCases,1);
results.fft_resident_single_shot_from_sparse_s=NaN(nCases,1);

results.operation_oracle_winner_v13=strings(nCases,1);
results.operation_oracle_s_v13=NaN(nCases,1);
results.single_shot_oracle_winner_v13=strings(nCases,1);
results.single_shot_oracle_s_v13=NaN(nCases,1);

% One row per measured FFT trial, with explicit mode.
maxRows=nCases*(nCold+nResident);
fftRows=repmat(struct('case_name','','mode','','trial',NaN,'fft_s',NaN),maxRows,1);
pos=0;

fprintf('\nBMD-MATLAB v1.3 adversarial FFT extension\n');
fprintf('==========================================\n');
fprintf('FFT_COLD and FFT_RESIDENT measured on all %d workloads.\n',nCases);
fprintf('FFT_RESIDENT reuses precomputed operand spectra and still returns coefficients.\n\n');

for i=1:nCases
    c=build_publication_case_v11(i);
    if ~strcmp(c.name,results.case_name{i})
        error('BMD:V13CaseOrder','Case mismatch at row %d.',i);
    end

    fprintf('  %02d/%02d %-29s ... ',i,nCases,c.name);

    %% Uncapped dense materialization from sparse, setup only.
    buildT=zeros(1,nBuild);
    pDense=[]; qDense=[];
    for k=1:nBuild
        tic;
        a=denseFromSparse(c.p_sparse,c.p_degree);
        b=denseFromSparse(c.q_sparse,c.q_degree);
        buildT(k)=toc;
        if k==1
            pDense=a; qDense=b;
        end
    end

    resultLen=c.result_degree_bound+1;
    nfft=2^nextpow2(resultLen);

    %% Precompute both operand spectra outside resident-operation timing.
    preT=zeros(1,nPre);
    pSpec=[]; qSpec=[];
    for k=1:nPre
        tic;
        fa=fft(pDense,nfft);
        fb=fft(qDense,nfft);
        preT(k)=toc;
        if k==1
            pSpec=fa; qSpec=fb;
        end
    end

    %% Warm-up outside all measured regions.
    fftCold(pDense,qDense,nfft,resultLen);
    fftResident(pSpec,qSpec,resultLen);

    %% FFT_COLD: full transforms every multiplication.
    coldT=zeros(1,nCold);
    firstCold=[];
    for k=1:nCold
        tic;
        z=fftCold(pDense,qDense,nfft,resultLen);
        coldT(k)=toc;
        if k==1, firstCold=z; end
        pos=pos+1;
        fftRows(pos).case_name=c.name;
        fftRows(pos).mode='FFT_COLD';
        fftRows(pos).trial=k;
        fftRows(pos).fft_s=coldT(k);
        if mod(k,progressEvery)==0 || k==nCold
            fprintf('[FFT_COLD %d/%d] ',k,nCold);
        end
    end

    %% FFT_RESIDENT: both operand spectra reusable/precomputed.
    residentT=zeros(1,nResident);
    firstResident=[];
    for k=1:nResident
        tic;
        z=fftResident(pSpec,qSpec,resultLen);
        residentT(k)=toc;
        if k==1, firstResident=z; end
        pos=pos+1;
        fftRows(pos).case_name=c.name;
        fftRows(pos).mode='FFT_RESIDENT';
        fftRows(pos).trial=k;
        fftRows(pos).fft_s=residentT(k);
        if mod(k,progressEvery)==0 || k==nResident
            fprintf('[FFT_RESIDENT %d/%d] ',k,nResident);
        end
    end

    %% Exact reference and strict correctness gates outside timing.
    exactSparse=sparse_terms_multiply(c.p_sparse,c.q_sparse);
    exactDense=denseFromSparse(exactSparse,c.result_degree_bound);

    [coldFrac,coldOK]=validateFFT(firstCold,exactDense);
    [residentFrac,residentOK]=validateFFT(firstResident,exactDense);

    if ~coldOK
        error('BMD:V13FFTColdValidation','FFT_COLD failed exact-after-rounding for %s.',c.name);
    end
    if ~residentOK
        error('BMD:V13FFTResidentValidation','FFT_RESIDENT failed exact-after-rounding for %s.',c.name);
    end
    if coldFrac>1e-6
        error('BMD:V13FFTColdResidual','FFT_COLD residual %.3g exceeds 1e-6 for %s.',coldFrac,c.name);
    end
    if residentFrac>1e-6
        error('BMD:V13FFTResidentResidual','FFT_RESIDENT residual %.3g exceeds 1e-6 for %s.',residentFrac,c.name);
    end

    %% Store setup and operation results.
    results.fft_build_median_s(i)=median(buildT);
    results.fft_length(i)=nfft;
    results.fft_operand_bytes(i)=workspace_bytes_v11(pDense)+workspace_bytes_v11(qDense);
    results.fft_precompute_median_s(i)=median(preT);
    results.fft_spectra_bytes(i)=workspace_bytes_v11(pSpec)+workspace_bytes_v11(qSpec);

    results.fft_cold_median_s(i)=median(coldT);
    results.fft_cold_q25_s(i)=pct(coldT,.25);
    results.fft_cold_q75_s(i)=pct(coldT,.75);
    results.fft_cold_result_bytes(i)=workspace_bytes_v11(firstCold);
    results.fft_cold_max_fractional_error(i)=coldFrac;
    results.fft_cold_exact_after_rounding(i)=double(coldOK);
    results.fft_cold_single_shot_from_sparse_s(i)=median(buildT)+median(coldT);

    results.fft_resident_median_s(i)=median(residentT);
    results.fft_resident_q25_s(i)=pct(residentT,.25);
    results.fft_resident_q75_s(i)=pct(residentT,.75);
    results.fft_resident_result_bytes(i)=workspace_bytes_v11(firstResident);
    results.fft_resident_max_fractional_error(i)=residentFrac;
    results.fft_resident_exact_after_rounding(i)=double(residentOK);
    results.fft_resident_single_shot_from_sparse_s(i)=median(buildT)+median(preT)+median(residentT);

    %% Strongest operation oracle: gives FFT the benefit of reusable spectra.
    [nm,t]=winnerV13(results.bmd_median_s(i),results.sparse_best_median_s(i), ...
        results.dense_median_s(i),logical(results.dense_eligible(i)), ...
        results.fft_cold_median_s(i),results.fft_resident_median_s(i));
    results.operation_oracle_winner_v13(i)=nm;
    results.operation_oracle_s_v13(i)=t;

    %% Single-shot oracle includes all setup costs appropriate to each state.
    [nm,t]=winnerV13(results.bmd_single_shot_from_sparse_s(i),results.sparse_best_median_s(i), ...
        results.dense_single_shot_from_sparse_s(i),logical(results.dense_eligible(i)), ...
        results.fft_cold_single_shot_from_sparse_s(i),results.fft_resident_single_shot_from_sparse_s(i));
    results.single_shot_oracle_winner_v13(i)=nm;
    results.single_shot_oracle_s_v13(i)=t;

    fprintf('FFTcold=%.3fms FFTresident=%.3fms *BMD=%.3fms sparse*=%.3fms winner=%s\n', ...
        1000*results.fft_cold_median_s(i),1000*results.fft_resident_median_s(i), ...
        1000*results.bmd_median_s(i),1000*results.sparse_best_median_s(i), ...
        char(results.operation_oracle_winner_v13(i)));
    writeFFTCheckpoint(checkpointDir,results(1:i,:),fftRows(1:pos),i,nCases);
end

fftTrials=struct2table(fftRows(1:pos));

if p.Results.SaveResults
    outDir=fullfile(root,'results_v13');
    if ~exist(outDir,'dir'), mkdir(outDir); end
    writetable(results,fullfile(outDir,'publication_validation_results_v13.csv'));
    writetable(coreTrials,fullfile(outDir,'publication_core_trials_v13.csv'));
    writetable(fftTrials,fullfile(outDir,'publication_fft_trials_v13.csv'));
    writeMetadata(outDir,nCold,nBuild,nPre,nResident,round(p.Results.DenseMaxCoefficients));
end
end

function writeFFTCheckpoint(checkpointDir,results,fftRows,caseIndex,nCases)
if isempty(checkpointDir), return; end
try
    if ~exist(checkpointDir,'dir'), mkdir(checkpointDir); end
    checkpoint=struct('results',results,'fftRows',fftRows, ...
        'caseIndex',caseIndex,'nCases',nCases,'timestamp',datestr(now,31)); %#ok<NASGU>
    tmpFile=fullfile(checkpointDir,'fft_checkpoint.tmp.mat');
    finalFile=fullfile(checkpointDir,'fft_checkpoint.mat');
    save(tmpFile,'checkpoint','-v7');
    movefile(tmpFile,finalFile,'f');
catch ME
    warning('BMD:CheckpointWriteFailed', ...
        'FFT MAT checkpoint could not be written; continuing benchmark: %s',ME.message);
end
try
    writetable(results,fullfile(checkpointDir,'fft_results_checkpoint.csv'));
    writetable(struct2table(fftRows),fullfile(checkpointDir,'fft_trials_checkpoint.csv'));
catch ME
    warning('BMD:CheckpointCSVSkipped', ...
        'FFT CSV checkpoint skipped; MAT checkpoint remains available: %s',ME.message);
end
fid=fopen(fullfile(checkpointDir,'fft_checkpoint_status.txt'),'w');
if fid>=0
    c=onCleanup(@()fclose(fid)); %#ok<NASGU>
    fprintf(fid,'Completed FFT cases: %d/%d\n',caseIndex,nCases);
    fprintf(fid,'Timestamp: %s\n',datestr(now,31));
end
end

function out=fftCold(a,b,nfft,nout)
fa=fft(a,nfft);
fb=fft(b,nfft);
out=ifft(fa.*fb,'symmetric');
out=out(1:nout);
end

function out=fftResident(fa,fb,nout)
out=ifft(fa.*fb,'symmetric');
out=out(1:nout);
end

function d=denseFromSparse(s,degreeBound)
d=zeros(1,degreeBound+1);
if isempty(s.exponents), return; end
idx=double(s.exponents)+1;
d(idx)=s.coefficients;
end

function [fracErr,exactOK]=validateFFT(out,exactDense)
rounded=round(out);
fracErr=max(abs(out-rounded));
exactOK=isequal(rounded,exactDense);
end

function q=pct(x,p)
x=sort(x(:));
pos=1+(numel(x)-1)*p;
lo=floor(pos); hi=ceil(pos);
if lo==hi
    q=x(lo);
else
    q=x(lo)+(pos-lo)*(x(hi)-x(lo));
end
end

function [name,t]=winnerV13(b,s,d,denseEligible,cold,resident)
vals=[b s cold resident];
names={'BMD','SPARSE','FFT_COLD','FFT_RESIDENT'};
if denseEligible && isfinite(d)
    vals(end+1)=d;
    names{end+1}='DENSE';
end
[t,idx]=min(vals);
name=string(names{idx});
end

function writeMetadata(outDir,nCold,nBuild,nPre,nResident,denseMax)
fid=fopen(fullfile(outDir,'run_metadata_v13.txt'),'w');
if fid<0, return; end
c=onCleanup(@()fclose(fid)); %#ok<NASGU>
fprintf(fid,'BMD-MATLAB v1.3 adversarial numerical-baseline rerun\n');
fprintf(fid,'Timestamp: %s\n',datestr(now,31));
fprintf(fid,'MATLAB: %s\n',version);
fprintf(fid,'Computer: %s\n',computer);
fprintf(fid,'Core *BMD/sparse/direct-conv trials: inherited from run_publication_validation_v111\n');
fprintf(fid,'FFT_COLD trials: %d\n',nCold);
fprintf(fid,'FFT dense-materialization trials: %d\n',nBuild);
fprintf(fid,'FFT operand-spectrum precompute trials: %d\n',nPre);
fprintf(fid,'FFT_RESIDENT trials: %d\n',nResident);
fprintf(fid,'Historical direct conv cap: %d coefficients\n',denseMax);
fprintf(fid,'FFT eligibility: all 60 cases, uncapped\n');
fprintf(fid,'FFT length: next power of two >= result coefficient count\n');
fprintf(fid,'FFT_COLD transform reuse: none\n');
fprintf(fid,'FFT_RESIDENT transform reuse: both operand spectra precomputed and reused\n');
fprintf(fid,'FFT_RESIDENT timed region: pointwise spectral multiply + inverse FFT + truncation\n');
fprintf(fid,'Product spectrum precomputation: prohibited\n');
fprintf(fid,'Frequency-domain-only output: not accepted as equivalent result\n');
fprintf(fid,'FFT correctness: exact equality after rounding vs exact sparse product\n');
fprintf(fid,'FFT residual tolerance: 1e-6\n');
end
