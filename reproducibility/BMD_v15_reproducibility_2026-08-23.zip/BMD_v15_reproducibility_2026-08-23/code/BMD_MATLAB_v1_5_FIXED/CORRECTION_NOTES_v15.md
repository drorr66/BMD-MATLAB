# v1.5 correction notes

## Corrected defects

1. Removed the second BMD pass that reused one manager and retained
   multiplication-generated unique-table nodes across repeated trials.
2. Reused the clean core BMD timing path, which compacts a fresh operand-only
   manager outside timing before every measured multiplication.
3. Preserved all raw core and FFT trials instead of discarding them in wrapper
   return values.
4. Added a BMD-only raw trial convenience file derived from the clean core
   table.
5. Added per-case recovery snapshots and progress output every ten trials.
6. Corrected v1.5 workspace variable names and expanded run metadata to record
   every operation-route repetition count.
7. Added `run_publication_tests_v15` to guard against product-node leakage
   between repeated BMD trials.
8. Added version-correct `_v15` full-operation and single-shot oracle columns;
   inherited `_v13` columns remain only for schema compatibility.

## Superseded data

Any result reported from `bmd_resident_symmetric_*` columns produced by the
earlier one-manager-across-trials implementation is superseded. In this
corrected package, those compatibility columns are aliases of the clean
fresh-manager core BMD measurement.
