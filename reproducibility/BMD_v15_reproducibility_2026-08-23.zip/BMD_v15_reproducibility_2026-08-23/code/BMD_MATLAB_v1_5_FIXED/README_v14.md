# BMD-MATLAB v1.4 — symmetric resident-state benchmark

## Purpose

v1.4 addresses a methodological asymmetry in v1.3.

v1.3 gave FFT an aggressive resident state (`FFT_RESIDENT`) in which both
operand spectra were precomputed outside the timed region, while *BMD was still
measured using the earlier cold-resident path.

v1.4 therefore adds a symmetric *BMD resident-state measurement.

## Symmetry rule

### FFT_RESIDENT
Prepared before timing:
- sparse-to-dense materialization
- FFT of operand A
- FFT of operand B

Timed:
- pointwise spectral multiplication
- inverse FFT
- truncation to the polynomial result length

Forbidden:
- precomputing the product spectrum
- retaining a pair-specific multiplication result

### BMD_RESIDENT
Prepared before timing:
- sparse-to-*BMD construction
- operand compaction
- canonical unique-table state
- invariant operand metadata

Timed:
- *BMD multiplication only

Forbidden:
- retaining pair-specific multiplication-cache entries across trials
- reusing a previously computed product

Before every timed *BMD multiplication, computed caches are cleared while the
resident operand DAG and unique table remain in memory.

This is the closest representation-state symmetry available in the current
MATLAB research implementation without changing the underlying *BMD algorithm.

## Important implementation requirement

v1.4 requires the BMDManager class to expose:

```matlab
clearComputedCaches()
```

which must clear only the computed add/multiply caches and their counters, while
preserving the canonical unique table and resident nodes.

If your current `BMDManager.m` does not yet provide this public method, add the
method below inside the public `methods` block:

```matlab
function clearComputedCaches(obj)
    obj.addCache = containers.Map('KeyType','char','ValueType','any');
    obj.mulCache = containers.Map('KeyType','char','ValueType','any');
    obj.addHits = 0;
    obj.addMisses = 0;
    obj.mulHits = 0;
    obj.mulMisses = 0;
end
```


## Package correction

This package uses the exact v1.3 parameter names:
`FFTColdTrials`, `FFTBuildTrials`, `FFTPrecomputeTrials`, and `FFTResidentTrials`.

## Run

```matlab
run_all_v14
```

## Output

- `results_v14/publication_validation_results_v14.csv`
- `results_v14/publication_bmd_resident_trials_v14.csv`
- `results_v14/run_metadata_v14.txt`

Run the exact same v1.4 artifact unchanged in both environments.
