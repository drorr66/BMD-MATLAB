# BMD-MATLAB v1.5 corrected — 50-trial publication benchmark

This package replaces the earlier v1.5 symmetric-pass implementation. The
earlier pass reused one `BMDManager` across repeated multiplication trials.
Clearing computed caches did not remove product and intermediate nodes from the
canonical unique table, so later trials did not start from an operand-only
state. Those symmetric-pass timings must not be used.

## Corrected BMD operation state

Before every measured BMD multiplication:

1. The two operands already exist as BMD DAGs.
2. A fresh compact manager containing only nodes reachable from the two operand
   roots is created outside the timed region.
3. The fresh manager has empty add/multiply caches and no nodes produced by a
   previous multiplication.
4. Only `multiply` is timed.

This is an operand-resident, product-cold operation. It is the BMD analogue of
`FFT_RESIDENT`: reusable operand representation is prepared before timing, but
the pair-specific product is not retained or precomputed.

The old compatibility column names
`bmd_resident_symmetric_median_s`, `bmd_resident_symmetric_q25_s`, and
`bmd_resident_symmetric_q75_s` are retained. They are aliases of the clean
core BMD measurements, not a second warm-unique-table pass.

The primary full-oracle columns are `operation_oracle_winner_v15`,
`operation_oracle_s_v15`, `single_shot_oracle_winner_v15`, and
`single_shot_oracle_s_v15`. Legacy `_v13` oracle columns remain only for schema
compatibility with the inherited runner.

## Repetition counts

Timed operation measurements:

- BMD_RESIDENT: 50 trials
- SPARSE_UNIQUE: 50 trials
- SPARSE_SORT_REDUCE: 50 trials
- direct conv: 50 trials when eligible
- FFT_COLD: 50 trials
- FFT_RESIDENT: 50 trials

Build and preparation measurements remain at three trials. Predictor timing
remains at five trials.

## Run

Extract the ZIP into its own MATLAB Drive directory. Open `run_all_v15.m` and
run that file. Do not run `run_all_v14.m`.

```matlab
run_all_v15
```

The runner prints progress after every ten operation trials. Recovery snapshots
are rewritten after every completed case under `results_v15/checkpoints/`.
They are intended to preserve diagnostic partial data if MATLAB Online is
interrupted; a publication run is complete only after all 60 cases finish.

## Final outputs

- `results_v15/publication_validation_results_v15.csv`
- `results_v15/publication_core_trials_v15.csv`
- `results_v15/publication_fft_trials_v15.csv`
- `results_v15/publication_bmd_resident_trials_v15.csv`
- `results_v15/run_metadata_v15.txt`

`publication_core_trials_v15.csv` contains one row per case and repetition,
with raw BMD, both sparse, and eligible direct-conv times. The FFT file contains
one row per case, route, and repetition. The BMD-only file is a convenience
view of the clean BMD column from the core trial table.

Expected final raw row counts with the default protocol:

- core trials: 3,000 rows
- FFT trials: 6,000 rows
- BMD convenience view: 3,000 rows

## Publication rules

- Run the exact same ZIP unchanged on Windows and MATLAB Online/Linux.
- Retain every raw trial file from both environments.
- Report medians and interquartile ranges.
- For close competitors, compute uncertainty from the raw trials and examine
  trial-order trends before declaring a robust winner.
- Do not use results from the superseded warm-unique-table symmetric pass.
