function run_publication_tests_v15()
%RUN_PUBLICATION_TESTS_V15 Guard the corrected product-cold BMD protocol.

fprintf('Running v1.5 corrected resident-state protocol tests...\n');

c=build_publication_case_v11(18);
[base,refs]=build_bmd_pair_from_sparse_v10(c.p_sparse,c.q_sparse);
[base,refs]=base.compact(refs);

% Trial 1 starts from an operand-only manager.
[m1,r1]=base.compact(refs);
s1Before=m1.stats(r1);
assert(s1Before.add_cache_entries==0 && s1Before.mul_cache_entries==0, ...
    'BMD:V15TestDirtyCaches','Fresh trial manager must have empty computed caches.');
out1=m1.multiply(r1(1,:),r1(2,:));
s1After=m1.stats(out1);

% Trial 2 must use a different fresh operand-only manager. Product and
% intermediate nodes created during trial 1 must not be present before it.
[m2,r2]=base.compact(refs);
s2Before=m2.stats(r2);
assert(s2Before.total_internal_nodes==s1Before.total_internal_nodes, ...
    'BMD:V15TestNodeLeak','Product nodes leaked into the next trial manager.');
assert(s2Before.unique_entries==s1Before.unique_entries, ...
    'BMD:V15TestUniqueLeak','Unique-table entries leaked into the next trial manager.');
assert(s2Before.add_cache_entries==0 && s2Before.mul_cache_entries==0, ...
    'BMD:V15TestDirtyCaches','Second trial manager must have empty computed caches.');
out2=m2.multiply(r2(1,:),r2(2,:));

for x=[0.5 0.999]
    a=m1.evaluate(out1,x);
    b=m2.evaluate(out2,x);
    scale=max([1 abs(a) abs(b)]);
    assert(abs(a-b)<=1e-10*scale,'BMD:V15TestResultMismatch', ...
        'Fresh-manager repeated products differ numerically.');
end

assert(s1After.total_internal_nodes>=s1Before.total_internal_nodes, ...
    'BMD:V15TestUnexpectedNodeCount','Product trial reduced manager node count unexpectedly.');

fprintf('v1.5 corrected resident-state protocol tests passed.\n');
end
