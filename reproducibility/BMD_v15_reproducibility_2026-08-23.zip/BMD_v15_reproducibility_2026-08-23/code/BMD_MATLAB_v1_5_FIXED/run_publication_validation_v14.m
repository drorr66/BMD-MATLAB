function [results,trials]=run_publication_validation_v14(varargin)
%RUN_PUBLICATION_VALIDATION_V14 Symmetric resident-state benchmark.
%
% Goal:
%   Compare mature resident states rather than asymmetric preparation.
%
% FFT_RESIDENT:
%   - dense operands materialized before timing
%   - operand spectra precomputed before timing
%   - timed region = pointwise spectral multiply + inverse FFT + truncation
%
% BMD_RESIDENT:
%   - compact operand manager built before timing
%   - operand compaction, root packing, and invariant operand metadata are
%     prepared before timing
%   - multiplication computed cache is cleared before every timed multiply
%   - timed region = multiply only on the already-resident compact manager
%
% Prohibited for both sides:
%   - precomputing the pair-specific product
%   - reusing a previous product
%   - retaining pair-specific multiplication cache entries across trials
%
% The *BMD path therefore receives state preparation analogous to FFT
% operand-spectrum precomputation, but not pair-specific result caching.

p=inputParser;
addParameter(p,'Trials',5,@(x)isnumeric(x)&&isscalar(x)&&x>=3);
addParameter(p,'BuildTrials',3,@(x)isnumeric(x)&&isscalar(x)&&x>=1);
addParameter(p,'PredictTrials',5,@(x)isnumeric(x)&&isscalar(x)&&x>=1);
addParameter(p,'DenseMaxCoefficients',250000,@(x)isnumeric(x)&&isscalar(x)&&x>=1000);
addParameter(p,'FFTColdTrials',5,@(x)isnumeric(x)&&isscalar(x)&&x>=3);
addParameter(p,'FFTBuildTrials',3,@(x)isnumeric(x)&&isscalar(x)&&x>=1);
addParameter(p,'FFTPrecomputeTrials',3,@(x)isnumeric(x)&&isscalar(x)&&x>=1);
addParameter(p,'FFTResidentTrials',5,@(x)isnumeric(x)&&isscalar(x)&&x>=3);
addParameter(p,'SaveResults',true,@(x)islogical(x)||ismember(x,[0 1]));
parse(p,varargin{:});

% First obtain the v1.3 adversarial baseline unchanged.
[baseResults,baseTrials]=run_publication_validation_v13( ...
    'Trials',p.Results.Trials, ...
    'BuildTrials',p.Results.BuildTrials, ...
    'PredictTrials',p.Results.PredictTrials, ...
    'DenseMaxCoefficients',p.Results.DenseMaxCoefficients, ...
    'FFTColdTrials',p.Results.FFTColdTrials, ...
    'FFTBuildTrials',p.Results.FFTBuildTrials, ...
    'FFTPrecomputeTrials',p.Results.FFTPrecomputeTrials, ...
    'FFTResidentTrials',p.Results.FFTResidentTrials, ...
    'SaveResults',false);

nCases=height(baseResults);
nTrials=round(p.Results.Trials);

bmdResidentTrials=NaN(nCases,nTrials);
bmdResidentMedian=NaN(nCases,1);
bmdResidentQ25=NaN(nCases,1);
bmdResidentQ75=NaN(nCases,1);

fprintf('\nBMD-MATLAB v1.4 symmetric resident *BMD pass\n');
fprintf('============================================\n');

for i=1:nCases
    c=build_publication_case_v11(i);

    % Prepare compact resident state OUTSIDE timed region.
    [mgr,refs]=build_bmd_pair_from_sparse_v10(c.p_sparse,c.q_sparse);
    [mgr,refs]=mgr.compact(refs);

    % Touch invariant metadata outside timed region.
    mgr.stats(refs);

    fprintf('  %02d/%02d %-29s ... ',i,nCases,c.name);

    try
        for k=1:nTrials
            % Clear pair-specific computed multiplication cache while retaining
            % the already-built canonical resident operand DAG and unique table.
            mgr.clearComputedCaches();

            tic;
            out=mgr.multiply(refs(1,:),refs(2,:)); %#ok<NASGU>
            bmdResidentTrials(i,k)=toc;
        end

        bmdResidentMedian(i)=median(bmdResidentTrials(i,:));
        bmdResidentQ25(i)=pct(bmdResidentTrials(i,:),.25);
        bmdResidentQ75(i)=pct(bmdResidentTrials(i,:),.75);

        fprintf('BMD_RESIDENT=%.3fms\n',1000*bmdResidentMedian(i));
    catch ME
        fprintf('ERROR:%s\n',ME.identifier);
        rethrow(ME);
    end
end

results=baseResults;
results.bmd_resident_symmetric_median_s=bmdResidentMedian;
results.bmd_resident_symmetric_q25_s=bmdResidentQ25;
results.bmd_resident_symmetric_q75_s=bmdResidentQ75;

% Symmetric resident oracle: strongest sparse/direct dense/FFT resident/*BMD resident.
winner=strings(nCases,1);
winnerS=NaN(nCases,1);
for i=1:nCases
    vals=[ ...
        bmdResidentMedian(i), ...
        results.sparse_best_median_s(i), ...
        results.fft_resident_median_s(i)];
    names=["BMD_RESIDENT","SPARSE","FFT_RESIDENT"];

    if results.dense_eligible(i) && isfinite(results.dense_median_s(i))
        vals(end+1)=results.dense_median_s(i);
        names(end+1)="DENSE";
    end

    [winnerS(i),ix]=min(vals);
    winner(i)=names(ix);
end

results.symmetric_resident_oracle_winner=winner;
results.symmetric_resident_oracle_s=winnerS;

% Trial table for the new *BMD resident state.
rows=nCases*nTrials;
trialCase=strings(rows,1);
trialFamily=strings(rows,1);
trialIndex=NaN(rows,1);
trialTime=NaN(rows,1);
pos=0;
for i=1:nCases
    for k=1:nTrials
        pos=pos+1;
        trialCase(pos)=string(baseResults.case_name{i});
        trialFamily(pos)=string(baseResults.family{i});
        trialIndex(pos)=k;
        trialTime(pos)=bmdResidentTrials(i,k);
    end
end
trials=table(trialCase,trialFamily,trialIndex,trialTime, ...
    'VariableNames',{'case_name','family','trial','bmd_resident_symmetric_s'});

if p.Results.SaveResults
    root=fileparts(mfilename('fullpath'));
    outDir=fullfile(root,'results_v14');
    if ~exist(outDir,'dir'), mkdir(outDir); end
    writetable(results,fullfile(outDir,'publication_validation_results_v14.csv'));
    writetable(trials,fullfile(outDir,'publication_bmd_resident_trials_v14.csv'));
    writeMetadataV14(outDir,nTrials);
end
end

function q=pct(x,p)
x=sort(x(:));
pos=1+(numel(x)-1)*p;
lo=floor(pos);
hi=ceil(pos);
if lo==hi
    q=x(lo);
else
    q=x(lo)+(pos-lo)*(x(hi)-x(lo));
end
end

function writeMetadataV14(outDir,nTrials)
fid=fopen(fullfile(outDir,'run_metadata_v14.txt'),'w');
if fid<0, return; end
c=onCleanup(@()fclose(fid));
fprintf(fid,'BMD-MATLAB v1.4 symmetric resident-state benchmark\n');
fprintf(fid,'Timestamp: %s\n',datestr(now,31));
fprintf(fid,'MATLAB: %s\n',version);
fprintf(fid,'Computer: %s\n',computer);
fprintf(fid,'BMD_RESIDENT trials: %d\n',nTrials);
fprintf(fid,'BMD resident preparation: compact operand DAG + invariant metadata before timing\n');
fprintf(fid,'BMD timed region: multiply only\n');
fprintf(fid,'BMD pair-specific multiply cache reuse: prohibited; caches cleared before every trial\n');
fprintf(fid,'FFT resident preparation: dense materialization + both operand spectra precomputed before timing\n');
fprintf(fid,'FFT timed region: pointwise spectral multiply + inverse FFT + truncation\n');
fprintf(fid,'FFT product spectrum precomputation: prohibited\n');
fprintf(fid,'Output equivalence: coefficient-domain result required\n');
end
