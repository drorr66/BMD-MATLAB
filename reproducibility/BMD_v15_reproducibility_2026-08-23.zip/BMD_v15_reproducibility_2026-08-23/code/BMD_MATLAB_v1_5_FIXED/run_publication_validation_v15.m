function [results,coreTrials,fftTrials,bmdTrials]=run_publication_validation_v15(varargin)
%RUN_PUBLICATION_VALIDATION_V15 Corrected 50-trial publication benchmark.
%
% Primary *BMD operation state:
%   - sparse-to-*BMD construction is outside timing
%   - a fresh compact manager containing only the two operand DAGs is
%     created outside timing before EVERY measured multiplication
%   - computed caches are empty and no product/intermediate nodes from an
%     earlier multiplication can survive into the timed region
%   - timed region = multiply only
%
% FFT_RESIDENT state:
%   - dense operands and both operand spectra are prepared outside timing
%   - product-spectrum precomputation is prohibited
%   - timed region = pointwise product + inverse FFT + truncation
%
% v1.5 increases operation measurements to 50 trials and preserves every
% raw observation for BMD, both sparse implementations, direct conv,
% FFT_COLD, and FFT_RESIDENT. Build/preparation measurements remain at 3.

rootDir=fileparts(mfilename('fullpath'));
addpath(genpath(rootDir));

p=inputParser;
addParameter(p,'Trials',50,@(x)isnumeric(x)&&isscalar(x)&&x>=3);
addParameter(p,'BuildTrials',3,@(x)isnumeric(x)&&isscalar(x)&&x>=1);
addParameter(p,'PredictTrials',5,@(x)isnumeric(x)&&isscalar(x)&&x>=1);
addParameter(p,'DenseMaxCoefficients',250000,@(x)isnumeric(x)&&isscalar(x)&&x>=1000);
addParameter(p,'FFTColdTrials',50,@(x)isnumeric(x)&&isscalar(x)&&x>=3);
addParameter(p,'FFTBuildTrials',3,@(x)isnumeric(x)&&isscalar(x)&&x>=1);
addParameter(p,'FFTPrecomputeTrials',3,@(x)isnumeric(x)&&isscalar(x)&&x>=1);
addParameter(p,'FFTResidentTrials',50,@(x)isnumeric(x)&&isscalar(x)&&x>=3);
addParameter(p,'ProgressEvery',10,@(x)isnumeric(x)&&isscalar(x)&&x>=1);
addParameter(p,'SaveResults',true,@(x)islogical(x)||ismember(x,[0 1]));
parse(p,varargin{:});

nTrials=round(p.Results.Trials);
nCold=round(p.Results.FFTColdTrials);
nResident=round(p.Results.FFTResidentTrials);
outDir=fullfile(rootDir,'results_v15');
checkpointDir=fullfile(outDir,'checkpoints');

fprintf('\nBMD-MATLAB v1.5 corrected 50-trial benchmark\n');
fprintf('================================================\n');
fprintf('Fresh operand-only *BMD manager before every timed multiply.\n');
fprintf('All raw operation trials will be retained.\n\n');

[baseResults,fftTrials,coreTrials]=run_publication_validation_v13( ...
    'Trials',nTrials, ...
    'BuildTrials',p.Results.BuildTrials, ...
    'PredictTrials',p.Results.PredictTrials, ...
    'DenseMaxCoefficients',p.Results.DenseMaxCoefficients, ...
    'FFTColdTrials',nCold, ...
    'FFTBuildTrials',p.Results.FFTBuildTrials, ...
    'FFTPrecomputeTrials',p.Results.FFTPrecomputeTrials, ...
    'FFTResidentTrials',nResident, ...
    'CheckpointDir',checkpointDir, ...
    'ProgressEvery',p.Results.ProgressEvery, ...
    'SaveResults',false);

nCases=height(baseResults);
if nCases~=60
    error('BMD:V15CaseCount','Expected 60 cases, got %d.',nCases);
end
if height(coreTrials)~=nCases*nTrials
    error('BMD:V15CoreTrialCount','Expected %d core rows, got %d.',nCases*nTrials,height(coreTrials));
end
if height(fftTrials)~=nCases*(nCold+nResident)
    error('BMD:V15FFTTrialCount','Expected %d FFT rows, got %d.',nCases*(nCold+nResident),height(fftTrials));
end

% Compatibility view: the clean core BMD measurement is already the
% symmetric operand-resident/product-cold route. It uses a fresh compact
% operand-only manager before every timed multiply. No second warm-unique-
% table pass is run.
results=baseResults;
results.bmd_resident_symmetric_median_s=results.bmd_median_s;
results.bmd_resident_symmetric_q25_s=results.bmd_q25_s;
results.bmd_resident_symmetric_q75_s=results.bmd_q75_s;
results.operation_oracle_winner_v15=results.operation_oracle_winner_v13;
results.operation_oracle_s_v15=results.operation_oracle_s_v13;
results.single_shot_oracle_winner_v15=results.single_shot_oracle_winner_v13;
results.single_shot_oracle_s_v15=results.single_shot_oracle_s_v13;

bmdTrials=coreTrials(:,{'case_name','family','trial','bmd_cold_s'});
bmdTrials.Properties.VariableNames{4}='bmd_resident_symmetric_s';

winner=strings(nCases,1);
winnerS=NaN(nCases,1);
for i=1:nCases
    vals=[results.bmd_median_s(i),results.sparse_best_median_s(i),results.fft_resident_median_s(i)];
    names=["BMD_RESIDENT","SPARSE","FFT_RESIDENT"];
    if results.dense_eligible(i) && isfinite(results.dense_median_s(i))
        vals(end+1)=results.dense_median_s(i); %#ok<AGROW>
        names(end+1)="DENSE"; %#ok<AGROW>
    end
    [winnerS(i),ix]=min(vals);
    winner(i)=names(ix);
end
results.symmetric_resident_oracle_winner=winner;
results.symmetric_resident_oracle_s=winnerS;

if p.Results.SaveResults
    if ~exist(outDir,'dir'), mkdir(outDir); end
    writetable(results,fullfile(outDir,'publication_validation_results_v15.csv'));
    writetable(coreTrials,fullfile(outDir,'publication_core_trials_v15.csv'));
    writetable(fftTrials,fullfile(outDir,'publication_fft_trials_v15.csv'));
    writetable(bmdTrials,fullfile(outDir,'publication_bmd_resident_trials_v15.csv'));
    writeMetadataV15(outDir,p.Results,nCases,height(coreTrials),height(fftTrials));
end
end

function writeMetadataV15(outDir,p,nCases,nCoreRows,nFFTRows)
fid=fopen(fullfile(outDir,'run_metadata_v15.txt'),'w');
if fid<0, return; end
c=onCleanup(@()fclose(fid)); %#ok<NASGU>
fprintf(fid,'BMD-MATLAB v1.5 corrected 50-trial publication benchmark\n');
fprintf(fid,'Timestamp: %s\n',datestr(now,31));
fprintf(fid,'MATLAB: %s\n',version);
fprintf(fid,'Computer: %s\n',computer);
fprintf(fid,'Cases: %d\n',nCases);
fprintf(fid,'BMD_RESIDENT trials per case: %d\n',round(p.Trials));
fprintf(fid,'SPARSE_UNIQUE trials per case: %d\n',round(p.Trials));
fprintf(fid,'SPARSE_SORT_REDUCE trials per case: %d\n',round(p.Trials));
fprintf(fid,'DIRECT_CONV trials per eligible case: %d\n',round(p.Trials));
fprintf(fid,'FFT_COLD trials per case: %d\n',round(p.FFTColdTrials));
fprintf(fid,'FFT_RESIDENT trials per case: %d\n',round(p.FFTResidentTrials));
fprintf(fid,'Build trials: %d\n',round(p.BuildTrials));
fprintf(fid,'Predictor trials: %d\n',round(p.PredictTrials));
fprintf(fid,'FFT build trials: %d\n',round(p.FFTBuildTrials));
fprintf(fid,'FFT precompute trials: %d\n',round(p.FFTPrecomputeTrials));
fprintf(fid,'Core raw rows: %d\n',nCoreRows);
fprintf(fid,'FFT raw rows: %d\n',nFFTRows);
fprintf(fid,'BMD preparation: fresh compact operand-only manager before every timed trial\n');
fprintf(fid,'BMD timed region: multiply only\n');
fprintf(fid,'BMD prior product/intermediate node reuse: prohibited by fresh manager per trial\n');
fprintf(fid,'FFT resident preparation: dense operands and both operand spectra precomputed before timing\n');
fprintf(fid,'FFT timed region: pointwise spectral multiply + inverse FFT + truncation\n');
fprintf(fid,'FFT product spectrum precomputation: prohibited\n');
fprintf(fid,'Output equivalence: coefficient-domain result required\n');
fprintf(fid,'Primary full-oracle columns: operation_oracle_*_v15 and single_shot_oracle_*_v15\n');
fprintf(fid,'Legacy *_v13 oracle columns are retained only for schema compatibility\n');
fprintf(fid,'Per-case recovery snapshots: results_v15/checkpoints/\n');
end
